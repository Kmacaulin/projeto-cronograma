// Inclua a biblioteca jQuery em seu projeto antes de usar este código.

// Aguarde o documento HTML ser carregado antes de executar o código JavaScript
$(document).ready(function() {

    // Adiciona um evento de clique ao botão de envio do formulário
    $('form').submit(function(event) {
      // Previne que o formulário seja enviado imediatamente após o clique no botão
      event.preventDefault();
  
      // Obtém os valores dos campos de entrada do formulário
      var subject = $('input[name=subject]').val();
      var task = $('textarea[name=task]').val();
      var deadline = $('input[name=deadline]').val();
      var time = $('input[name=time]').val();
  
      // Cria um novo elemento para exibir as informações do cronograma
      var scheduleItem = $('<li></li>');
      scheduleItem.append('<h3>' + subject + '</h3>');
      scheduleItem.append('<p>' + task + '</p>');
      scheduleItem.append('<p>Prazo: ' + deadline + ' às ' + time + '</p>');
  
      // Adiciona o novo elemento ao cronograma
      $('#schedule').append(scheduleItem);
  
      // Limpa os valores dos campos de entrada do formulário
      $('input[name=subject]').val('');
      $('textarea[name=task]').val('');
      $('input[name=deadline]').val('');
      $('input[name=time]').val('');
    });
  
    // Adiciona um seletor de data e hora aos campos de entrada de "prazo" e "hora"
    $('input[name=deadline]').datetimepicker({
      format: 'Y-m-d',
      timepicker: false
    });
    $('input[name=time]').datetimepicker({
      format: 'H:i',
      datepicker: false
    });
  
  });
  